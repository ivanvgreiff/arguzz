# Phase II Master Implementation Plan: Coverage-Guided Scheduling

This document is the **master implementation plan** for Phase II, derived from [Pro_Report_4.md](./Pro_Report_4.md) and [Pro_Report_5.md](./Pro_Report_5.md), and grounded in the current source code as delivered by Phase I. It defines the sub-phases from which detailed implementation subplans will be created.

**Rule**: No guesses. All statements are tied to file paths and code facts. Where confidence is not 100%, the gap is explicitly stated.

**Foundational documents**: Pro_Report_4.md (architecture specification) and Pro_Report_5.md (parameter calibration and extensions). These two documents **trump** the Phase I plan's forward-looking references to Phase II (PHASE_I_IMPLEMENTATION_PLAN.md §6 lines 264–267), but the overall direction is consistent.

---

## 0. Current Status Quo (What Phase I Delivered)

### 0.1 What exists in the source code

| Component | File | What it provides |
|-----------|------|-----------------|
| 8 mutation kinds | `fuzzer.py` lines 117–126: `MUTATION_KINDS = ["COMP_OUT_MOD", "LOAD_VAL_MOD", "STORE_OUT_MOD", "PRE_EXEC_REG_MOD", "INSTR_TYPE_MOD", "MEM_VAL_MOD", "INSTR_WORD_MOD_FULL", "INSTR_WORD_MOD_SUR"]` | `|K| = 8` |
| Valid steps per kind | `inspection_data.py` `get_valid_steps_for_kind(kind)` returns sorted unique step list per mutation kind. Steps are filtered by major category (e.g., COMP_OUT_MOD: major 0–4; LOAD_VAL_MOD: major 5; STORE_OUT_MOD: major 6; etc.) | `S_k` sets |
| Step selection | `step_selector.py`: `ZonedStepSelector` (5%/90%/5% init/core/final); `CoverageGuidedSelector` (stub, behaves identically to zoned). Factory `create_selector("zoned"/"guided")`. | Current selector is zoned-random; Phase II replaces with bandit. |
| Kind selection | `fuzzer.py` line 264: `kind = self.rng.choice(self.MUTATION_KINDS)` when `kind="all"` | Uniform random; Phase II replaces with bandit arm selection. |
| Touch bitmap per run | `executor.py`: `MutationExecutionResult.touch_bitmap: Optional[bytes]` (65536 bytes) | `X_t` |
| Global bitmap (max-merge) | `fuzzer.py`: `self.global_touch_bitmap: bytearray(65536)`. Updated via `merge_into_global`. | `G` (but stores max, not boolean or frequency) |
| New-touch count per run | `fuzzer.py`: `result.new_touch = count_new_bits(run_bitmap, global_bitmap)` | `Δ_new_t` |
| Campaign stats | `fuzzer.py`: `CampaignStats.new_touch_count`, `total_distinct_touched` | Cumulative aggregates |
| Failure context per run | `executor.py`: `MutationExecutionResult.failures: List[ConstraintFailure]` | `F_t` (exact set, each has `.constraint_loc()`, `.major`, `.minor`) |
| Selector reward hookup | `fuzzer.py` line 390: `self.selector.record_mutation(step, new_coverage + result.new_touch)` | Simple combined reward; Phase II replaces with proper bandit update |
| Value generation | `value_generator.py`: `CompositeValueGenerator` ("mixed" strategy), supports random, bitflip, boundary, arithmetic sub-strategies. | Phase II §9 extends with local/global mode scheduling |
| Inspection data | `inspection_data.py`: `InspectionData.from_inspection(host, args)` returns cycles, steps, transactions. Each cycle has `.step`, `.major`, `.minor`, `.pc`. | Source of `S_k`, `T`, major/minor per step |
| FNV-1a hash (Python) | `touch_coverage.py`: `fnv1a_touch_hash(loc, major, minor)` | For inverse mapping / debugging |
| Measured occupancy | Phase 3.2 report: 1599 distinct buckets, 192676 total touches per run, ~2.4% bitmap occupancy | Confirms MAP_SIZE=65536 is adequate |

### 0.2 What does NOT exist yet (Phase II must build)

| Missing | Required for |
|---------|-------------|
| Touch **frequency** array (`freq[i]` = #runs where bucket `i` was touched) | Rarity scoring (Pro_Report_4 §5.2) |
| Failure **frequency** map (`ffreq[c]` = #runs where FailKey `c` appeared) | Failure novelty scoring (Pro_Report_4 §5.3) |
| Touch **seen** boolean bitmap (distinct from max-merge) | New-touch detection (currently `global_bitmap[i] == 0` serves this role, but a separate boolean is cleaner per Pro_Report_4 §5.1) |
| Rolling window of `Δ_new_t` for saturation detection | Novelty→rarity switch (Pro_Report_4 §6.1) |
| Reward computation function | Pro_Report_4 §6 |
| Discounted-UCB bandit | Pro_Report_4 §7 |
| Arm universe `(kind, step_bucket)` | Pro_Report_4 §4.1 |
| Nested step-level bandit (or ε-greedy) | Pro_Report_4 §8 |
| Major/minor diagnostic counters | Pro_Report_5 §10 |
| Pilot calibration for `τ_new`, `τ_fail_count`, `K_rare` | Pro_Report_5 §11 |

### 0.3 Consistency check: Phase I plan vs Pro Reports

The Phase I plan (§6) stated: "Phase 2 (scheduling, corpus, bandits): Deferred to Phase II; Phase I only collects touch coverage and 'new touch' count." This is fully consistent with Pro_Report_4/5, which define Phase II as the scheduling layer built on top of Phase I's touch infrastructure. No disagreements found.

One clarification: Pro_Report_4 §5.1 recommends a separate boolean `seen` bitmap (`G[i] ∈ {0,1}`). Our Phase I `global_touch_bitmap` uses `max`-merge (values 0–255). For Phase II, we can derive `seen` from `global_bitmap[i] > 0`, OR maintain a separate boolean array. **Decision**: Use existing `global_bitmap[i] > 0` as the "seen" test (avoids adding another 64KB array). This is functionally identical to a separate boolean bitmap and avoids redundancy.

---

## 1. Sub-Phase Structure

Phase II is organized into **eight sub-phases**, derived from Pro_Report_4 §12 and modified by Pro_Report_5 §11.2 (which inserts a pilot calibration phase). Each will have its own detailed implementation subplan created before implementation.

| Sub-Phase | Name | Scope | Dependencies |
|-----------|------|-------|-------------|
| **II.0** | Baseline Touch Snapshot | Run unmutated with `A4_COVERAGE_TOUCH=1`; record baseline touched indices and distinct count. | Phase I complete |
| **II.1** | Arm Universe Construction | Compute `S_k`, `T`, `B_count`, `B`, enumerate available arms `(k,b)`. | II.0 (for `T` from inspection) |
| **II.1.5** | Pilot Calibration | Run `N_pilot` random mutations; calibrate `τ_new`, `τ_fail_count`, `K_rare`, `W`, `γ` from pilot statistics. | II.1 (arm universe for random sampling) |
| **II.2** | CoverageState + Reward | Implement `CoverageState` (freq arrays, rolling window, fail freq); implement `compute_reward()`. | II.1.5 (calibrated parameters) |
| **II.3** | Discounted-UCB Bandit | Implement `DiscountedUCB` with lazy decay, forced exploration, nested step-level selection. | II.2 (reward function) |
| **II.4** | Campaign Loop Integration | Replace current selector with bandit-driven `(kind, step)` selection; log per-run diagnostics. | II.3 (bandit), II.2 (reward) |
| **II.5** | A/B Experiments | Compare uniform vs bandit scheduling; tune `c`, `λ`, `p_local`. | II.4 (working system) |
| **II.6** | Persistence + Resume | Persist coverage state, bandit state, rolling window to disk. | II.4 |

**Phase II.7 (Bug Mode)** from Pro_Report_4 §12 is deferred: it only activates if `ACCEPTED` is observed, which has not happened yet. It will be planned if/when needed.

---

## 2. Parameter Inventory (Centralized)

This section consolidates every parameter from Pro_Report_4 and Pro_Report_5 §11, classified by how it should be determined.

### 2.1 HARD parameters (fixed, structural)

| # | Parameter | Value | Rationale |
|---|-----------|-------|-----------|
| 1 | MAP_SIZE (M) | 65536 | Phase I measured ~2.4% occupancy; collisions negligible (Phase 3.4 report §7). |
| 2 | Counter type | uint8 (0–255), saturating | AFL standard; counters not primary signal (Pro_Report_5 §1). |
| 3 | TouchKey | `(constraint_loc, major, minor)` | Stable across builds/programs; matches Phase I hash (Phase 3.4 report §7.3). |
| 4 | FailKey | `(constraint_loc, major, minor)` | Small cardinality; stored as exact Python set. |
| 5 | Touched definition | `X_t[i] > 0` | Binary signal dominates (Pro_Report_5 §1). |
| 6 | Saturation threshold | `median(Δ_new window) < 1` (i.e., median == 0) | Robust integer logic (Pro_Report_5 §11, item 12). |
| 7 | τ_fail_new | 2 | Low sensitivity; failure novelty `Δ_fail` is small integer (Pro_Report_5 §11, item 16). |
| 8 | Rarity weight form | `w(i) = 1/sqrt(1 + freq[i])` | Standard diminishing returns (Pro_Report_5 §11, item 14). |
| 9 | ε (numeric stability) | 1e-6 | Not a tuning parameter (Pro_Report_5 §11, item 22). |
| 10 | λ (failure novelty weight) default | 0.2 | Conservative; keeps failure secondary (Pro_Report_4 §6.6). Tunable via A/B in II.5. |
| 11 | Nested step selection | Discounted-UCB (same structure as arm bandit) | Recommended over ε-greedy (Pro_Report_4 §8.1). |

### 2.2 DERIVED parameters (computed per campaign from trace/budget)

These are computed deterministically from the campaign budget N, the number of mutation kinds K=8, and the trace step horizon T.

**(12) T (step horizon)**
- Formula: `T = 1 + max(union of S_k for all k)`
- Inputs: From `InspectionData.get_valid_steps_for_kind(k)` for all 8 kinds.

**(13) B_count (number of step buckets)**
- Formula: `B_count = pow2_clamp(floor(N / (K * n_target)), B_min, B_max)` where `n_target=3`, `B_min=16`, `B_max=128`, `K=8`.
- Inputs: N (campaign budget).
- Example: N=1000 → `floor(1000 / (8*3)) = 41` → round to power of 2 → B_count=32.

**(14) B (steps per bucket)**
- Formula: `B = ceil(T / B_count)`
- Inputs: T, B_count.

**(15) n_min (forced exploration minimum pulls)**
- Formula: `n_min = 1 if N >= num_arms else 0` where `num_arms = K * B_count`.
- Inputs: N, num_arms.

**(16) W (rolling window size)**
- Formula: `W = clamp(floor(0.05 * N), 30, 150)`
- Inputs: N.

**(17) γ (discount factor)**
- Formula: `γ = 2^(-1/H)` where `H = clamp(floor(0.2 * N), 50, 300)`.
- Inputs: N.
- Example: N=1000 → H=200 → γ ≈ 0.9965.

### 2.3 CALIBRATE ONCE parameters (from pilot, Phase II.1.5)

| # | Parameter | Calibration method | Default if pilot skipped |
|---|-----------|-------------------|--------------------------|
| 18 | τ_new (novelty scaling) | 75th percentile of `{Δ_new_t > 0}` from pilot, clamped [16, 256] | 64 |
| 19 | τ_fail_count (cascade penalty) | 75th percentile of `n_fail_t` among non-crash pilot runs | 25 |
| 20 | K_rare (# rare bits to average) | `clamp(floor(0.02 * median(|U_t|)), 16, 64)` from pilot | 32 |

### 2.4 TUNE VIA A/B parameters (Phase II.5)

| # | Parameter | Default | A/B range |
|---|-----------|---------|-----------|
| 21 | c (UCB exploration coefficient) | 0.25 | {0.15, 0.25, 0.4} |
| 22 | λ (failure novelty weight) | 0.2 | {0.1, 0.2, 0.3} |
| 23 | p_local schedule (mutation value) | 0.7→0.4 | schedule A: 0.8→0.6, B: 0.7→0.4, C: fixed 0.6 |

---

## 3. Reward Function (Complete Specification)

Reproduced from Pro_Report_4 §6 with Pro_Report_5 §11 refinements. This is the function that `compute_reward` in Phase II.2 will implement.

### 3.1 Inputs (per run t)

- `U_t = {i : X_t[i] > 0}` — touched indices (from `touch_bitmap`)
- `F_t` — failure context set (from `failures`)
- `n_fail_t = len(failures)` — raw failure instance count
- `outcome` — ACCEPTED / REJECTED / CRASH / etc.
- `touch_bitmap is None` — indicates crash before witgen completed

### 3.2 Global state (updated after each run)

- `G[i]` — seen bitmap (`global_touch_bitmap[i] > 0`)
- `freq[i]` — touch frequency array (new in Phase II; `#runs where i was touched`)
- `ffreq[c]` — failure frequency dict (new in Phase II; `#runs where FailKey c appeared`)
- `Δ_new_window` — rolling deque of last W values of `Δ_new_t`

### 3.3 Components

**Novelty score** (bounded [0,1]):
```
Δ_new_t = |{i ∈ U_t : G[i] == 0}|     (already computed as count_new_bits)
S_new_t = 1 - exp(-Δ_new_t / τ_new)
```

**Saturation indicator**:
```
sat_t = 1 if median(Δ_new_window) < 1 else 0
```

**Rarity score** (bounded (0,1]):
```
w(i) = 1 / sqrt(1 + freq[i])        (using freq BEFORE updating with this run)
R_t = top K_rare indices in U_t by largest w(i)
S_rare_t = (1/K_rare) * Σ_{i ∈ R_t} w(i)
```

**Failure novelty** (bounded [0,1]):
```
Δ_fail_t = |{c ∈ F_t : ffreq[c] == 0}|
S_fail_new_t = 1 - exp(-Δ_fail_t / τ_fail_new)
```

**Execution quality** (bounded [0,1]):
```
Q_t = 0                                    if CRASH or touch_bitmap is None
Q_t = exp(-n_fail_t / τ_fail_count)        otherwise
```

**Touch score** (novelty or rarity depending on saturation):
```
S_touch_t = S_new_t     if sat_t == 0
S_touch_t = S_rare_t    if sat_t == 1
```

**Final reward** (bounded [0,1]):
```
r_t = min(1, Q_t * (S_touch_t + λ * S_fail_new_t) / (1 + λ))
```
**Special case**: if `outcome == ACCEPTED`, override `r_t = 1`.

### 3.4 Update order (critical)

After computing reward for run t:
1. Update `G[i]` for all `i ∈ U_t` (mark seen).
2. Update `freq[i] += 1` for all `i ∈ U_t`.
3. Update `ffreq[c] += 1` for all `c ∈ F_t`.
4. Append `Δ_new_t` to rolling window.
5. Update bandit arm stats with `r_t`.

**Why this order**: Reward is computed using the state *before* this run's contribution. This ensures the first run to touch a bucket gets the novelty credit, not a later run that finds the same bucket after it was already merged.

---

## 4. Bandit Model (Complete Specification)

Reproduced from Pro_Report_4 §7 with Pro_Report_5 §11 refinements.

### 4.1 Arms

Each arm `a = (k, b)` where `k ∈ MUTATION_KINDS` and `b ∈ {0, ..., B_count-1}`. Arm is available if `S_{k,b} = {s ∈ S_k : floor(s/B) == b}` is non-empty.

### 4.2 Per-arm state (lazy discounted)

```
ArmState:
    N: float       # discounted pull count
    S: float       # discounted reward sum
    last_t: int    # last iteration this arm was updated
```

Before reading N,S for arm a at global iteration t:
```
Δt = t - a.last_t
a.N *= γ^Δt
a.S *= γ^Δt
a.last_t = t
```

Mean: `μ_a = a.S / max(a.N, ε)`

### 4.3 UCB selection

```
N_tot = Σ_a N_a   (over available arms)
UCB(a) = μ_a + c * sqrt(log(1 + N_tot) / max(N_a, ε))
```

Select `a* = argmax_{a available} UCB(a)`, with forced exploration: if any available arm has `N_a < n_min`, prioritize it first.

### 4.4 Nested step selection

Within chosen arm `a = (k, b)`, maintain per-step stats `StepState(N, S, last_t)` for each `s ∈ S_{k,b}`. Apply the same discounted-UCB to select a specific step.

### 4.5 After each run

Update arm `a`'s stats: `a.N += 1; a.S += r_t; a.last_t = t`. Similarly for the step-level state.

---

## 5. Sub-Phase Details

### Phase II.0 — Baseline Touch Snapshot

**Goal**: Capture the baseline (unmutated) touch set for reference and diagnostic comparison.

**Actions**:
1. Run `run_baseline(host, args)` with `A4_COVERAGE_TOUCH=1` in the environment (requires modifying `run_baseline` to accept an optional env override, or manually setting the env var).
2. Parse the touch bitmap from the output.
3. Record `baseline_touched_indices = {i : bitmap[i] > 0}` and `baseline_distinct = len(baseline_touched_indices)`.
4. Store as a file or in campaign init code.

**Deliverable**: Baseline touch snapshot. This is used for diagnostics (e.g., "did this mutation run touch anything the baseline didn't?") but is NOT used in the reward function (reward compares against campaign global, not baseline).

**Note**: This is a small, self-contained step. It can be combined with II.1 in a single subplan if desired.

---

### Phase II.1 — Arm Universe Construction

**Goal**: Compute the arm universe from inspection data and campaign budget.

**Actions**:
1. From `InspectionData`, compute `S_k` for each of the 8 mutation kinds using `get_valid_steps_for_kind(k)`.
2. Compute `T = 1 + max(union of all S_k)`.
3. Given campaign budget `N`, compute `B_count` and `B` using the DERIVED formulas (§2.2 items 13–14).
4. For each `(k, b)` pair, compute `S_{k,b} = {s ∈ S_k : floor(s/B) == b}`. An arm is available if `S_{k,b}` is non-empty.
5. Enumerate available arms; report total count and average steps per arm-bucket.

**Deliverable**: `ArmUniverse` data structure mapping `(kind, bucket) -> list_of_valid_steps`. Reproducible from inspection + budget.

**Source code facts**:
- `get_valid_steps_for_kind` is in `inspection_data.py` lines 147–215. It returns sorted unique steps.
- For our default guest program with `--in1 5 --in4 10`, inspection shows 3930 total steps (`InspectionData.summary()` — from Phase 3.2 integration test output).

**Confidence gap**: I have not directly verified `max(union of S_k)` for all 8 kinds. The inspection summary shows 3930 steps total. The actual `T` value depends on which of these are valid for at least one mutation kind. This should be computed at implementation time from the actual inspection data.

---

### Phase II.1.5 — Pilot Calibration

**Goal**: Run `N_pilot` random mutations to calibrate `τ_new`, `τ_fail_count`, `K_rare`.

**Actions**:
1. Compute `N_pilot = clamp(floor(0.05 * N), 30, 100)` (Pro_Report_5 §11.2). For N=1000, N_pilot=50.
2. Run N_pilot mutations with uniform-random kind and step selection (existing `ZonedStepSelector` with `kind="all"` achieves this).
3. For each run, record: `Δ_new_t`, `|U_t|`, `n_fail_t`, whether crash.
4. Compute:
   - `τ_new = percentile_75({Δ_new_t : Δ_new_t > 0})`, clamped [16, 256]. If no runs have Δ_new > 0 (unlikely), use default 64.
   - `τ_fail_count = percentile_75({n_fail_t : not crash})`, clamped to minimum 5 to avoid over-penalizing.
   - `K_rare = clamp(floor(0.02 * median(|U_t|)), 16, 64)`.
5. Also compute DERIVED parameters that depend on N: `W`, `γ`, `B_count`, `n_min`.
6. Freeze all calibrated parameters.

**Deliverable**: Frozen parameter set. Pilot runs contribute to the campaign (their coverage is merged into global state; they count toward N).

**Key design decision**: Pilot runs are NOT thrown away. They are the first `N_pilot` runs of the campaign. After calibration, the bandit takes over for the remaining `N - N_pilot` runs. This avoids wasting budget.

---

### Phase II.2 — CoverageState + Reward

**Goal**: Implement the global coverage state and the `compute_reward` function.

**Actions**:
1. Create `a4/standalone/coverage_state.py` (new module) with:
   - `CoverageState` class holding: `seen` (derived from existing `global_touch_bitmap`), `freq` (new `array.array('I', [0]*MAP_SIZE)`), `fail_freq` (new `dict[tuple, int]`), `rolling_window` (new `collections.deque(maxlen=W)`).
   - `compute_reward(exec_result, coverage_state, params) -> (float, dict)` — returns `(r_t, diagnostics)`.
   - `update_state(exec_result, coverage_state)` — performs the update steps in §3.4.
2. The `compute_reward` function must be **deterministic** and **unit-testable** (given a fake touch bitmap and failure list, it should return the correct reward).

**Relationship to existing code**: The existing `global_touch_bitmap` in `fuzzer.py` will be wrapped or replaced by `CoverageState`. The `count_new_bits` and `merge_into_global` functions from `touch_coverage.py` will be used internally.

**Major/minor diagnostic counters** (Pro_Report_5 §10): Add `maj_seen: Dict[int, int]` and `maj_min_seen: Dict[Tuple[int,int], int]` to `CoverageState`. Update per run from `failures` list (which has `.major`, `.minor`). These are logged diagnostics, not fed into reward.

---

### Phase II.3 — Discounted-UCB Bandit

**Goal**: Implement the bandit that selects `(kind, step)`.

**Actions**:
1. Create `a4/standalone/bandit.py` (new module) with:
   - `ArmState` dataclass: `N: float`, `S: float`, `last_t: int`.
   - `DiscountedUCBScheduler` class:
     - Constructor takes arm universe, parameters (γ, c, n_min, ε).
     - `select_arm(t) -> (kind, bucket)`: lazy-decay all arms, apply forced exploration, compute UCB, return argmax.
     - `select_step(kind, bucket, t) -> step`: nested bandit over steps within the bucket.
     - `update(kind, bucket, step, reward, t)`: update arm + step stats.
2. Unit tests: given known arm stats and parameters, verify selection and decay behavior.

**Relationship to existing code**: This replaces the current `StepSelector` entirely for the bandit campaign. The `CoverageGuidedSelector` stub in `step_selector.py` will NOT be extended; instead, the bandit scheduler is a new top-level component that the campaign loop calls directly, bypassing the old selector interface. The old `ZonedStepSelector` remains available for non-bandit campaigns and for the pilot phase.

---

### Phase II.4 — Campaign Loop Integration

**Goal**: Wire the bandit scheduler and reward function into the campaign loop.

**Actions**:
1. In `A4Fuzzer.run_campaign`, after the pilot phase (first N_pilot runs with random selection), switch to bandit-driven selection for the remaining runs.
2. Replace the current flow:
   ```
   kind = self.rng.choice(MUTATION_KINDS)
   step = self.selector.select_step(self.data, kind)
   ```
   with:
   ```
   kind, bucket = self.scheduler.select_arm(t)
   step = self.scheduler.select_step(kind, bucket, t)
   ```
3. After each run, compute reward and update:
   ```
   reward, diag = compute_reward(exec_result, self.coverage_state, self.params)
   update_state(exec_result, self.coverage_state)
   self.scheduler.update(kind, bucket, step, reward, t)
   ```
4. Log per-run diagnostics: selected arm, reward components (S_touch, S_fail_new, Q_t, r_t), whether in novelty or rarity mode.
5. Campaign summary includes: arm pull distribution, reward histogram, saturation transition point, top arms by mean reward.

**Deliverable**: End-to-end run of a campaign (e.g., 200–500 mutations) showing nontrivial adaptation.

---

### Phase II.5 — A/B Experiments

**Goal**: Compare bandit scheduling against uniform baseline; tune remaining parameters.

**Actions**:
1. Run 3 campaigns each for: (a) uniform scheduling (existing `ZonedStepSelector`), (b) bandit scheduling.
2. Measure: distinct touched buckets vs mutation count, sum of rare touch scores, unique failure contexts, crash rate.
3. A/B tune: `c` ∈ {0.15, 0.25, 0.4}, `λ` ∈ {0.1, 0.2, 0.3}, `p_local` schedule options.

**Deliverable**: A single recommended configuration; documented in a report.

---

### Phase II.6 — Persistence + Resume

**Goal**: Save all scheduler state so a campaign can be resumed.

**Actions**:
1. Persist: `CoverageState` (freq array, fail_freq, rolling window, global bitmap), `DiscountedUCBScheduler` state (all arm + step states), calibrated parameters.
2. Format: JSON for parameters and arm states; raw bytes for freq array and bitmap.
3. Load on campaign resume.

**Deliverable**: Resume a campaign from a checkpoint file without losing learned policy.

---

## 6. Implementation Order and Dependencies

```
Phase II.0 (Baseline Touch)
    │
    ▼
Phase II.1 (Arm Universe)
    │
    ▼
Phase II.1.5 (Pilot Calibration)
    │
    ▼
Phase II.2 (CoverageState + Reward)
    │
    ▼
Phase II.3 (Bandit)
    │
    ▼
Phase II.4 (Campaign Integration)
    │
    ▼
Phase II.5 (A/B Experiments)
    │
    ▼
Phase II.6 (Persistence)
```

Each sub-phase depends on the previous. Sub-phases II.0 and II.1 are small and can be combined into a single subplan. Phase II.1.5 is a calibration step that runs as the first portion of a campaign, not a separate campaign.

---

## 7. Files Expected to Be Created or Modified

| File | Sub-Phase | Change |
|------|-----------|--------|
| `a4/standalone/coverage_state.py` | **II.2** | **New**: CoverageState, compute_reward, update_state |
| `a4/standalone/bandit.py` | **II.3** | **New**: ArmState, DiscountedUCBScheduler |
| `a4/standalone/fuzzer.py` | **II.1, II.1.5, II.4** | Arm universe construction, pilot calibration, bandit-driven campaign loop, diagnostic logging |
| `a4/core/executor.py` | **II.0** | Optional: allow `run_baseline` to accept env override for `A4_COVERAGE_TOUCH` |
| `a4/standalone/tests/test_reward.py` | **II.2** | **New**: Unit tests for compute_reward |
| `a4/standalone/tests/test_bandit.py` | **II.3** | **New**: Unit tests for DiscountedUCB |
| `a4/docs/touch/Phase II/` | **All** | Subplans and reports per sub-phase |

No changes expected to: `ffi.cpp`, `witgen.h`, `touch_coverage.py`, `constraint_parser.py`, `coverage_db.py` (unless persistence uses DB).

---

## 8. Consistency with Pro Reports

| Pro Report recommendation | Plan coverage | Notes |
|---------------------------|---------------|-------|
| Two-level scheduler (arm bandit + step bandit) | II.3 + II.4 | As specified |
| Novelty → rarity switch | II.2 (reward function) | As specified |
| Discounted-UCB with lazy decay | II.3 | As specified |
| Pilot calibration for τ_new, τ_fail_count, K_rare | II.1.5 | As specified; Pro_Report_5 §11.2 |
| DERIVED parameters from budget | II.1 | B_count, W, γ, n_min formulas from Pro_Report_5 §11 |
| A/B for c, λ, p_local | II.5 | As specified |
| Major/minor diagnostic counters | II.2 (CoverageState) | As mandatory diagnostics per Pro_Report_5 §10 |
| Debug evidence on interesting runs | II.4 (logging) | Store touched indices + config on high-reward runs |
| Bug mode / exploitation loop | Deferred | Only relevant if ACCEPTED is observed |
| Local/global mutation value mode | Deferred to II.5 or later | p_local schedule tuning; not the core scheduling architecture |

---

## 9. Open Questions and Confidence Gaps

1. **Exact T value**: I have not directly computed `max(union of S_k)` for all 8 kinds from the current inspection data. The inspection summary shows 3930 steps. This must be computed at implementation time.

2. **Pilot N_pilot interaction with campaign budget**: The pilot runs count toward N. If `N=100` and `N_pilot=30`, only 70 runs use the bandit. For very small N, the pilot may consume too much budget. The formula `N_pilot = clamp(0.05*N, 30, 100)` handles this for N ≥ 600 (pilot ≤ 100). For N < 600, the pilot is 30 runs, leaving N-30 for bandit. For N < 60, we should skip calibration entirely and use defaults. This edge case must be handled in II.1.5.

3. **Value generation (p_local)**: Pro_Report_4 §9 recommends a two-mode distribution (local vs global moves) with a schedule. The current `CompositeValueGenerator` in `value_generator.py` already has multiple sub-strategies (random, bitflip, boundary, arithmetic) selected by the "mixed" strategy. Adapting this to a `p_local`-controlled two-mode scheme requires understanding how each sub-strategy maps to "local" vs "global." This will be detailed in the II.5 subplan.

4. **Interaction between bandit and existing `CoverageGuidedSelector`**: The bandit replaces the selector entirely. The `record_mutation` call in `fuzzer.py` line 390 (which currently calls `self.selector.record_mutation(step, ...)`) will be replaced by `self.scheduler.update(...)`. The old selector interface is not used by the bandit.

---

*End of Phase II Master Implementation Plan. Detailed subplans for each sub-phase will be created incrementally before implementation.*
